module.exports.Token=require("./token.model")
module.exports.Media=require("./media.model")

module.exports.User=require("./user.model")
module.exports.Driver=require("./driverProfile.model")

const {Message,Text}=require("./message.model")

module.exports.Message=Message
module.exports.Text=Text
module.exports.Booking=require("./booking.model")
